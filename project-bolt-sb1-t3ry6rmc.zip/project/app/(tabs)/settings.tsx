import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  Modal,
  ScrollView,
  Alert,
} from 'react-native';
import { useRouter } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function SettingsScreen() {
  const router = useRouter();
  const [debitRate, setDebitRate] = useState('3');
  const [creditRate, setCreditRate] = useState('4.7');
  const [installmentRate, setInstallmentRate] = useState('2');
  const [selectedLanguage, setSelectedLanguage] = useState('Português');
  const [showLanguageModal, setShowLanguageModal] = useState(false);

  const languages = ['Português', 'English', 'Español'];

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    try {
      const savedSettings = await AsyncStorage.getItem('calculator_settings');
      if (savedSettings) {
        const settings = JSON.parse(savedSettings);
        setDebitRate(settings.debitRate.toString());
        setCreditRate(settings.creditRate.toString());
        setInstallmentRate(settings.installmentRate.toString());
      }
    } catch (error) {
      console.error('Error loading settings:', error);
    }
  };

  const saveSettings = async () => {
    try {
      const settings = {
        debitRate: parseFloat(debitRate) || 3,
        creditRate: parseFloat(creditRate) || 4.7,
        installmentRate: parseFloat(installmentRate) || 2,
      };

      await AsyncStorage.setItem('calculator_settings', JSON.stringify(settings));
      
      Alert.alert(
        'Sucesso',
        'Configurações salvas com sucesso!',
        [
          {
            text: 'OK',
            onPress: () => router.back(),
          },
        ]
      );
    } catch (error) {
      console.error('Error saving settings:', error);
      Alert.alert('Erro', 'Erro ao salvar configurações');
    }
  };

  const validateAndSetRate = (value: string, setter: (val: string) => void) => {
    // Allow numbers and decimal point
    const cleaned = value.replace(/[^0-9.]/g, '');
    
    // Prevent multiple decimal points
    const parts = cleaned.split('.');
    if (parts.length > 2) {
      return;
    }
    
    setter(cleaned);
  };

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.title}>CONFIGURAÇÕES</Text>
      </View>

      <View style={styles.content}>
        {/* Debit Rate */}
        <View style={styles.inputGroup}>
          <Text style={styles.label}>TAXA NO DÉBITO =</Text>
          <View style={styles.inputContainer}>
            <TextInput
              style={styles.input}
              value={debitRate}
              onChangeText={(text) => validateAndSetRate(text, setDebitRate)}
              keyboardType="numeric"
              placeholder="3"
            />
            <Text style={styles.percentSymbol}>%</Text>
          </View>
        </View>

        {/* Credit Rate */}
        <View style={styles.inputGroup}>
          <Text style={styles.label}>TAXA NO CRÉDITO =</Text>
          <View style={styles.inputContainer}>
            <TextInput
              style={styles.input}
              value={creditRate}
              onChangeText={(text) => validateAndSetRate(text, setCreditRate)}
              keyboardType="numeric"
              placeholder="4.7"
            />
            <Text style={styles.percentSymbol}>%</Text>
          </View>
        </View>

        {/* Installment Rate */}
        <View style={styles.inputGroup}>
          <Text style={styles.label}>TAXA CRÉDITO POR PARCELA =</Text>
          <View style={styles.inputContainer}>
            <TextInput
              style={styles.input}
              value={installmentRate}
              onChangeText={(text) => validateAndSetRate(text, setInstallmentRate)}
              keyboardType="numeric"
              placeholder="2"
            />
            <Text style={styles.percentSymbol}>%</Text>
          </View>
        </View>

        {/* Language Section */}
        <View style={styles.languageSection}>
          <Text style={styles.languageTitle}>ALTERAR IDIOMA</Text>
          
          <TouchableOpacity 
            style={styles.languageDropdown}
            onPress={() => setShowLanguageModal(true)}
          >
            <Text style={styles.languageText}>{selectedLanguage}</Text>
            <Text style={styles.dropdownArrow}>▼</Text>
          </TouchableOpacity>
        </View>

        {/* Save Button */}
        <TouchableOpacity style={styles.saveButton} onPress={saveSettings}>
          <Text style={styles.saveButtonText}>SALVAR TAXAS</Text>
        </TouchableOpacity>
      </View>

      {/* Language Modal */}
      <Modal
        visible={showLanguageModal}
        transparent={true}
        animationType="slide"
        onRequestClose={() => setShowLanguageModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <ScrollView>
              {languages.map((language, index) => (
                <TouchableOpacity
                  key={index}
                  style={styles.modalOption}
                  onPress={() => {
                    setSelectedLanguage(language);
                    setShowLanguageModal(false);
                  }}
                >
                  <Text style={styles.modalOptionText}>{language}</Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0f0f0',
  },
  header: {
    backgroundColor: '#e2e8f0',
    paddingHorizontal: 20,
    paddingTop: 60,
    paddingBottom: 30,
    alignItems: 'center',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#4285f4',
  },
  content: {
    flex: 1,
    paddingHorizontal: 20,
    paddingTop: 40,
  },
  inputGroup: {
    marginBottom: 40,
  },
  label: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1a202c',
    marginBottom: 10,
    textAlign: 'center',
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  input: {
    borderBottomWidth: 2,
    borderBottomColor: '#ef4444',
    fontSize: 24,
    fontWeight: 'bold',
    color: '#1a202c',
    textAlign: 'center',
    minWidth: 80,
    paddingVertical: 5,
    paddingHorizontal: 10,
  },
  percentSymbol: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#1a202c',
    marginLeft: 5,
  },
  languageSection: {
    marginTop: 20,
    marginBottom: 40,
  },
  languageTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#ef4444',
    textAlign: 'center',
    marginBottom: 20,
  },
  languageDropdown: {
    backgroundColor: '#fff',
    paddingHorizontal: 20,
    paddingVertical: 15,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#d1d5db',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  languageText: {
    fontSize: 18,
    color: '#4285f4',
    fontWeight: '500',
  },
  dropdownArrow: {
    fontSize: 14,
    color: '#6b7280',
  },
  saveButton: {
    backgroundColor: '#f97316',
    paddingVertical: 18,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 20,
  },
  saveButtonText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#fff',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    backgroundColor: '#fff',
    width: '80%',
    maxHeight: '50%',
    borderRadius: 12,
    paddingVertical: 20,
  },
  modalOption: {
    paddingHorizontal: 20,
    paddingVertical: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#e5e7eb',
  },
  modalOptionText: {
    fontSize: 16,
    color: '#1a202c',
  },
});