import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  StatusBar,
  Modal,
  ScrollView,
  Switch,
  SafeAreaView,
  Dimensions,
} from 'react-native';
import { useRouter } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';

const { height: screenHeight } = Dimensions.get('window');

interface Settings {
  debitRate: number;
  creditRate: number;
  installmentRate: number;
}

export default function HomeScreen() {
  const router = useRouter();
  const [amount, setAmount] = useState('0.00');
  const [settings, setSettings] = useState<Settings>({
    debitRate: 3,
    creditRate: 4.7,
    installmentRate: 2,
  });
  const [selectedPayment, setSelectedPayment] = useState({
    type: 'debit',
    installments: 1,
    rate: 3,
    label: 'Débito (3%)',
  });
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [passFeesToClient, setPassFeesToClient] = useState(true);

  const paymentOptions = [
    { type: 'debit', installments: 1, label: 'Débito' },
    { type: 'credit', installments: 1, label: 'Crédito - 1 Parcela' },
    { type: 'credit', installments: 2, label: 'Crédito - 2 Parcelas' },
    { type: 'credit', installments: 3, label: 'Crédito - 3 Parcelas' },
    { type: 'credit', installments: 4, label: 'Crédito - 4 Parcelas' },
    { type: 'credit', installments: 5, label: 'Crédito - 5 Parcelas' },
    { type: 'credit', installments: 6, label: 'Crédito - 6 Parcelas' },
    { type: 'credit', installments: 7, label: 'Crédito - 7 Parcelas' },
    { type: 'credit', installments: 8, label: 'Crédito - 8 Parcelas' },
    { type: 'credit', installments: 9, label: 'Crédito - 9 Parcelas' },
    { type: 'credit', installments: 10, label: 'Crédito - 10 Parcelas' },
    { type: 'credit', installments: 11, label: 'Crédito - 11 Parcelas' },
    { type: 'credit', installments: 12, label: 'Crédito - 12 Parcelas' },
    { type: 'credit', installments: 13, label: 'Crédito - 13 Parcelas' },
    { type: 'credit', installments: 14, label: 'Crédito - 14 Parcelas' },
    { type: 'credit', installments: 15, label: 'Crédito - 15 Parcelas' },
    { type: 'credit', installments: 16, label: 'Crédito - 16 Parcelas' },
    { type: 'credit', installments: 17, label: 'Crédito - 17 Parcelas' },
    { type: 'credit', installments: 18, label: 'Crédito - 18 Parcelas' },
  ];

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    try {
      const savedSettings = await AsyncStorage.getItem('calculator_settings');
      if (savedSettings) {
        const parsed = JSON.parse(savedSettings);
        setSettings(parsed);
        updateSelectedPaymentRate(selectedPayment, parsed);
      }
    } catch (error) {
      console.error('Error loading settings:', error);
    }
  };

  const updateSelectedPaymentRate = (payment: any, currentSettings: Settings) => {
    let rate = 0;
    if (payment.type === 'debit') {
      rate = currentSettings.debitRate;
    } else {
      rate = currentSettings.creditRate + (payment.installments - 1) * currentSettings.installmentRate;
    }
    
    setSelectedPayment({
      ...payment,
      rate,
      label: `${payment.label} (${rate.toFixed(1)}%)`,
    });
  };

  const handleNumberPress = (num: string) => {
    if (amount === '0.00') {
      setAmount(num === '.' ? '0.' : num);
    } else {
      const currentAmount = amount.replace(',', '.');
      if (num === '.' && currentAmount.includes('.')) return;
      
      const newAmount = currentAmount + num;
      setAmount(newAmount);
    }
  };

  const handleBackspace = () => {
    if (amount.length <= 1) {
      setAmount('0.00');
    } else {
      setAmount(amount.slice(0, -1));
    }
  };

  const handleClear = () => {
    setAmount('0.00');
  };

  const formatCurrency = (value: number) => {
    return `R$${value.toFixed(2).replace('.', ',')}`;
  };

  const calculateValues = () => {
    const numericAmount = parseFloat(amount.replace(',', '.')) || 0;
    const feeRate = selectedPayment.rate / 100;

    if (passFeesToClient) {
      // Quando repassa taxa: valor informado é o que o vendedor quer receber
      // Cliente paga = valor / (1 - taxa) 
      const clientPays = numericAmount / (1 - feeRate);
      const feeAmount = clientPays - numericAmount;
      const sellerReceives = numericAmount;
      const operatorReceives = feeAmount;
      
      return {
        clientPays,
        sellerReceives,
        operatorReceives,
      };
    } else {
      // Quando não repassa taxa: valor informado é o que o cliente paga
      const feeAmount = numericAmount * feeRate;
      const clientPays = numericAmount;
      const sellerReceives = numericAmount - feeAmount;
      const operatorReceives = feeAmount;
      
      return {
        clientPays,
        sellerReceives,
        operatorReceives,
      };
    }
  };

  const selectPayment = (option: any) => {
    updateSelectedPaymentRate(option, settings);
    setShowPaymentModal(false);
  };

  const values = calculateValues();

  const renderKeypadButton = (value: string, onPress: () => void, style?: any) => (
    <TouchableOpacity style={[styles.keypadButton, style]} onPress={onPress}>
      <Text style={styles.keypadButtonText}>{value}</Text>
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#4a5568" />
      
      <ScrollView style={styles.scrollContainer} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.amountDisplay}>${amount}</Text>
          <Text style={styles.formLabel}>FORMA DE PAGAMENTO</Text>
          
          <TouchableOpacity 
            style={styles.dropdown}
            onPress={() => setShowPaymentModal(true)}
          >
            <Text style={styles.dropdownText}>{selectedPayment.label}</Text>
            <Text style={styles.dropdownArrow}>▼</Text>
          </TouchableOpacity>

          <View style={styles.toggleContainer}>
            <Text style={styles.toggleLabel}>Repassar taxas!</Text>
            <Switch
              value={passFeesToClient}
              onValueChange={setPassFeesToClient}
              trackColor={{ false: '#ccc', true: '#4285f4' }}
              thumbColor="#fff"
            />
          </View>
        </View>

        {/* Results Display */}
        <View style={styles.resultsContainer}>
          <View style={[styles.resultRow, styles.clientRow]}>
            <Text style={styles.resultLabel}>Seu cliente paga</Text>
            <Text style={styles.resultValue}>{formatCurrency(values.clientPays)}</Text>
          </View>
          
          <View style={[styles.resultRow, styles.sellerRow]}>
            <Text style={styles.resultLabel}>Você recebe</Text>
            <Text style={styles.resultValue}>{formatCurrency(values.sellerReceives)}</Text>
          </View>
          
          <View style={[styles.resultRow, styles.operatorRow]}>
            <Text style={styles.resultLabel}>Operadora recebe</Text>
            <Text style={styles.resultValue}>{formatCurrency(values.operatorReceives)}</Text>
          </View>
        </View>

        <Text style={styles.paymentFormLabel}>Forma de Pagamento:</Text>

        {/* Keypad */}
        <View style={styles.keypad}>
          <View style={styles.keypadRow}>
            {renderKeypadButton('1', () => handleNumberPress('1'))}
            {renderKeypadButton('2', () => handleNumberPress('2'))}
            {renderKeypadButton('3', () => handleNumberPress('3'))}
          </View>
          <View style={styles.keypadRow}>
            {renderKeypadButton('4', () => handleNumberPress('4'))}
            {renderKeypadButton('5', () => handleNumberPress('5'))}
            {renderKeypadButton('6', () => handleNumberPress('6'))}
          </View>
          <View style={styles.keypadRow}>
            {renderKeypadButton('7', () => handleNumberPress('7'))}
            {renderKeypadButton('8', () => handleNumberPress('8'))}
            {renderKeypadButton('9', () => handleNumberPress('9'))}
          </View>
          <View style={styles.keypadRow}>
            {renderKeypadButton('.', () => handleNumberPress('.'))}
            {renderKeypadButton('0', () => handleNumberPress('0'))}
            <TouchableOpacity style={[styles.keypadButton, styles.deleteButton]} onPress={handleBackspace}>
              <Text style={styles.deleteButtonText}>⌫</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Action Buttons */}
        <View style={styles.actionButtons}>
          <TouchableOpacity style={styles.clearButton} onPress={handleClear}>
            <Text style={styles.buttonText}>ZERAR CÁLCULOS</Text>
          </TouchableOpacity>
          
          <TouchableOpacity 
            style={styles.configButton} 
            onPress={() => router.push('/(tabs)/settings')}
          >
            <Text style={styles.buttonText}>CONFIGURAR TAXAS</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>

      {/* Payment Options Modal */}
      <Modal
        visible={showPaymentModal}
        transparent={true}
        animationType="slide"
        onRequestClose={() => setShowPaymentModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <ScrollView>
              {paymentOptions.map((option, index) => {
                let rate = 0;
                if (option.type === 'debit') {
                  rate = settings.debitRate;
                } else {
                  rate = settings.creditRate + (option.installments - 1) * settings.installmentRate;
                }
                
                return (
                  <TouchableOpacity
                    key={index}
                    style={styles.modalOption}
                    onPress={() => selectPayment({
                      ...option,
                      rate,
                    })}
                  >
                    <Text style={styles.modalOptionText}>
                      {option.label} ({rate.toFixed(1)}%)
                    </Text>
                  </TouchableOpacity>
                );
              })}
            </ScrollView>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0f0f0',
  },
  scrollContainer: {
    flex: 1,
  },
  header: {
    backgroundColor: '#e2e8f0',
    paddingHorizontal: 16,
    paddingTop: 20,
    paddingBottom: 16,
    alignItems: 'center',
  },
  amountDisplay: {
    fontSize: 36,
    fontWeight: 'bold',
    color: '#1a202c',
    marginBottom: 8,
  },
  formLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: '#4285f4',
    marginBottom: 12,
  },
  dropdown: {
    backgroundColor: '#fff',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#d1d5db',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    width: '100%',
    marginBottom: 16,
  },
  dropdownText: {
    fontSize: 14,
    color: '#1a202c',
    flex: 1,
  },
  dropdownArrow: {
    fontSize: 14,
    color: '#6b7280',
  },
  toggleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    width: '100%',
  },
  toggleLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: '#4285f4',
  },
  resultsContainer: {
    marginHorizontal: 0,
  },
  resultRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  clientRow: {
    backgroundColor: '#4285f4',
  },
  sellerRow: {
    backgroundColor: '#34d399',
  },
  operatorRow: {
    backgroundColor: '#ef4444',
  },
  resultLabel: {
    fontSize: 16,
    fontWeight: '500',
    color: '#fff',
  },
  resultValue: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#fff',
  },
  paymentFormLabel: {
    backgroundColor: '#fbbf24',
    textAlign: 'center',
    paddingVertical: 12,
    fontSize: 14,
    fontWeight: '600',
    color: '#1a202c',
  },
  keypad: {
    paddingHorizontal: 16,
    paddingVertical: 16,
  },
  keypadRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  keypadButton: {
    backgroundColor: '#fff',
    flex: 1,
    height: 45,
    marginHorizontal: 3,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#d1d5db',
  },
  deleteButton: {
    backgroundColor: '#1a202c',
  },
  keypadButtonText: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1a202c',
  },
  deleteButtonText: {
    fontSize: 18,
    fontWeight: '600',
    color: '#fff',
  },
  actionButtons: {
    paddingHorizontal: 16,
    paddingBottom: 30,
    gap: 12,
  },
  clearButton: {
    backgroundColor: '#f97316',
    paddingVertical: 14,
    borderRadius: 8,
    alignItems: 'center',
  },
  configButton: {
    backgroundColor: '#10b981',
    paddingVertical: 14,
    borderRadius: 8,
    alignItems: 'center',
  },
  buttonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#fff',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    backgroundColor: '#fff',
    width: '90%',
    maxHeight: '70%',
    borderRadius: 12,
    paddingVertical: 20,
  },
  modalOption: {
    paddingHorizontal: 20,
    paddingVertical: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#e5e7eb',
  },
  modalOptionText: {
    fontSize: 14,
    color: '#1a202c',
  },
});