# Calculadora de Taxas - App Mobile

Este é um aplicativo React Native/Expo para calcular taxas de pagamento.

## Como instalar e executar:

1. Certifique-se de estar na pasta do projeto (onde está este arquivo README.md)
2. Instale as dependências:
   ```
   npm install
   ```
3. Instale o Expo CLI globalmente:
   ```
   npm install -g @expo/cli
   ```
4. Inicie o projeto:
   ```
   npx expo start
   ```

## Para gerar APK:

1. Configure o EAS Build:
   ```
   npx eas build:configure
   ```
2. Gere o APK:
   ```
   npx eas build --platform android --profile preview
   ```

## Estrutura do projeto:

- `app/` - Telas do aplicativo
- `hooks/` - Hooks customizados
- `package.json` - Dependências do projeto
- `app.json` - Configurações do Expo